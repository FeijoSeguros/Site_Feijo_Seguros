
import React from 'react';

const ContactSection = () => {
  return (
    <section id="contact" className="py-16 bg-gray-50"></section>
  );
};

export default ContactSection;

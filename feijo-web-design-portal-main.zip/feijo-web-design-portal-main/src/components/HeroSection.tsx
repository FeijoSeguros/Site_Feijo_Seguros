
import React, { useEffect } from 'react';

import topoImage from '../../public/topo.png';
import topoMobileImage from "../../public/topo-mobile.png";

const HeroSection = () => {
    useEffect(() => {
        // Preload hero images
        const preloadImages = () => {
            const imgDesktop = new Image();
            imgDesktop.src = topoImage;
            
            const imgMobile = new Image();
            imgMobile.src = topoMobileImage;
        };
        
        preloadImages();
    }, []);

    return (
        <div className="bg-[#DADADB] bg-cover bg-center relative h-[320px] flex items-center justify-center">
            <div className="container mx-auto px-4 h-full flex items-center relative">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center h-full w-full">
                    <div className='md:block hidden'>
                        <img 
                            src={topoImage} 
                            alt="topo" 
                            className="object-cover h-[320px] mx-auto"
                            loading="eager"
                            fetchPriority="high"
                        />
                    </div>
                    <div className='block md:hidden'>
                        <img 
                            src={topoMobileImage} 
                            alt="topo" 
                            className="object-cover h-[131px] mx-auto"
                            loading="eager"
                            fetchPriority="high"
                        />
                    </div>
                    <div className="text-left flex flex-col justify-center z-10">
                        <h1 className="text-2xl md:text-4xl font-bold mb-4 text-[#FA0108] ">
                            FEIJÓ SEGUROS
                        </h1>
                        <h1 className="text-xl md:text-3xl font-bold mb-4 text-[#45484A] ">
                            Proteção e segurança para o que importa
                        </h1>
                        <p className="text-base md:text-lg mb-6 text-[#45484A]">
                            Na Feijó Seguros, oferecemos as melhores soluções em seguros para você, sua família e seu patrimônio.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default HeroSection;


import { useState, useCallback, useEffect } from 'react';
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { Switch } from "@/components/ui/switch";
import { GarageInfoSection } from "./GarageInfoSection";
import { VehicleInfoSection } from "./VehicleInfoSection";
import { PersonalInfoSection } from "./PersonalInfoSection";
import { DriverInfoSection } from "./DriverInfoSection";
import { AutoInsuranceFormData } from "./types";
import { Label } from "../ui/label";
import { Separator } from "../ui/separator";

const formSchema = z.object({
  document_number: z.string().min(1, "CPF/CNPJ é obrigatório"),
  full_name: z.string().min(1, "Nome/Razão Social é obrigatório"),
  phone: z.string().min(1, "Telefone é obrigatório"),
  email: z.string().email("Email inválido"),
  insurance_type: z.enum(["new", "renewal"]),
  
  // Optional fields
  address: z.string().optional(),
  zip_code: z.string().optional(),
  birth_date: z.string().optional(),
  marital_status: z.enum(["single", "married", "divorced", "widowed", "other"]).optional(),
  gender: z.enum(["male", "female", "other"]).optional(),
  residence_type: z.enum(["house", "apartment", "condominium"]).optional(),
  
  is_new_vehicle: z.boolean().optional(),
  license_plate: z.string().optional(),
  chassis_number: z.string().optional(),
  manufacture_year: z.number().optional(),
  model_year: z.number().optional(),
  model: z.string().optional(),
  fuel_type: z.string().optional(),
  is_financed: z.boolean().optional(),
  is_armored: z.boolean().optional(),
  has_natural_gas: z.boolean().optional(),
  has_sunroof: z.boolean().optional(),
  parking_zip_code: z.string().optional(),
  
  has_home_garage: z.boolean().optional(),
  has_automatic_gate: z.boolean().optional(),
  has_work_garage: z.boolean().optional(),
  has_school_garage: z.boolean().optional(),
  vehicle_usage: z.enum(["personal", "work", "passenger_transport"]).optional(),
  vehicles_at_residence: z.number().optional(),
  covers_young_drivers: z.boolean().optional(),
  condutor_menor: z.string().optional(),
  
  is_driver_insured: z.boolean().optional(),
  driver_document_number: z.string().optional(),
  driver_full_name: z.string().optional(),
  driver_birth_date: z.string().optional(),
  driver_marital_status: z.enum(["single", "married", "divorced", "widowed", "other"]).optional(),
  driver_gender: z.enum(["male", "female", "other"]).optional(),
  driver_relationship: z.string().optional(),
  seller: z.enum(["Felipe", "Renan", "Renata", "Gabriel"]),
});

interface AutoInsuranceQuoteFormProps {
  onSuccess?: (data: AutoInsuranceFormData) => void;
  onFileChange?: (file: File | null) => void;
  isSubmitting?: boolean;
}

const AutoInsuranceQuoteForm = ({ 
  onSuccess, 
  onFileChange, 
  isSubmitting = false 
}: AutoInsuranceQuoteFormProps) => {
  const [showDriverInfo, setShowDriverInfo] = useState(false);
  const [localIsSubmitting, setLocalIsSubmitting] = useState(false);
  const [policyFile, setPolicyFile] = useState<File | null>(null);
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      insurance_type: "new",
      is_new_vehicle: false,
      license_plate: undefined,
      chassis_number: undefined,
      is_financed: false,
      is_armored: false,
      has_natural_gas: false,
      has_sunroof: false,
      has_home_garage: false,
      has_automatic_gate: false,
      has_work_garage: false,
      has_school_garage: false,
      vehicle_usage: "personal",
      vehicles_at_residence: 1,
      covers_young_drivers: false,
      is_driver_insured: true,
      driver_document_number: undefined,
      driver_full_name: undefined,
      driver_birth_date: undefined,
      driver_marital_status: undefined,
      driver_gender: undefined,
      driver_relationship: undefined,
      seller: "Felipe",
    },
  });

  // Watch for insurance_type changes to determine which sections to show
  const insuranceType = form.watch("insurance_type");
  const isRenewalType = insuranceType === "renewal";
  
  // Handle file change
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0] || null;
    setPolicyFile(selectedFile);
    
    if (onFileChange) {
      onFileChange(selectedFile);
    }
  };

  async function onSubmit(values: z.infer<typeof formSchema>) {
    try {
      setLocalIsSubmitting(true);
      
      if (!values.document_number || !values.full_name || !values.email || !values.phone) {
        toast.error("Por favor, preencha todos os campos obrigatórios.");
        setLocalIsSubmitting(false);
        return;
      }
      
      if (onSuccess) {
        // Ensure all required fields for AutoInsuranceFormData are provided
        const formData: AutoInsuranceFormData = {
          document_number: values.document_number,
          full_name: values.full_name,
          phone: values.phone,
          email: values.email,
          insurance_type: values.insurance_type,
          seller: values.seller,
          // Optional fields can remain as they are
          address: values.address,
          zip_code: values.zip_code,
          birth_date: values.birth_date,
          marital_status: values.marital_status,
          gender: values.gender,
          residence_type: values.residence_type,
          is_new_vehicle: values.is_new_vehicle,
          license_plate: values.license_plate,
          chassis_number: values.chassis_number,
          manufacture_year: values.manufacture_year,
          model_year: values.model_year,
          model: values.model,
          fuel_type: values.fuel_type,
          is_financed: values.is_financed,
          is_armored: values.is_armored,
          has_natural_gas: values.has_natural_gas,
          has_sunroof: values.has_sunroof,
          parking_zip_code: values.parking_zip_code,
          has_home_garage: values.has_home_garage,
          has_automatic_gate: values.has_automatic_gate,
          has_work_garage: values.has_work_garage,
          has_school_garage: values.has_school_garage,
          vehicle_usage: values.vehicle_usage,
          vehicles_at_residence: values.vehicles_at_residence,
          covers_young_drivers: values.covers_young_drivers,
          condutor_menor: values.condutor_menor,
          is_driver_insured: values.is_driver_insured,
          driver_document_number: values.driver_document_number,
          driver_full_name: values.driver_full_name,
          driver_birth_date: values.driver_birth_date,
          driver_marital_status: values.driver_marital_status,
          driver_gender: values.driver_gender,
          driver_relationship: values.driver_relationship,
        };
        
        onSuccess(formData);
        form.reset();
        setShowDriverInfo(false);
        setPolicyFile(null);
      }
      
    } catch (error) {
      toast.error("Erro ao enviar cotação. Tente novamente.");
      console.error(error);
    } finally {
      setLocalIsSubmitting(false);
    }
  }

  return (
    <Card className="w-full">
      <CardContent className="p-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            
            {/* Insurance Type Selection */}
            <div className="space-y-4">
              <FormField
                control={form.control}
                name="insurance_type"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormLabel className="text-lg font-semibold text-[#fa0008]">Tipo de Seguro</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="flex flex-col space-y-1 sm:flex-row sm:space-y-0 sm:space-x-4"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="new" id="new" />
                          <Label htmlFor="new">Seguro Novo</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="renewal" id="renewal" />
                          <Label htmlFor="renewal">Renovação</Label>
                        </div>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            {/* Policy File Upload */}
            <div className="space-y-4">
              <Label htmlFor="policy-file" className="text-lg font-semibold text-[#fa0008]">
                {isRenewalType ? "Anexar Apólice Atual" : "Anexar Apólice (opcional)"}
              </Label>
              <Input
                id="policy-file"
                type="file"
                accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                onChange={handleFileChange}
                className="cursor-pointer"
              />
              {policyFile && (
                <p className="text-sm text-green-600">
                  Arquivo selecionado: {policyFile.name}
                </p>
              )}
            </div>
            
            <Separator className="my-4" />
            
            {/* Personal Information Section */}
            <PersonalInfoSection />
            
            {/* Conditional sections based on insurance type */}
            {!isRenewalType && (
              <>
                {/* Vehicle Information Section */}
                <VehicleInfoSection />
                
                {/* Garage Information Section */}
                <GarageInfoSection />
                
                {/* Principal Driver Information Section */}
                <DriverInfoSection
                  showDriverInfo={showDriverInfo}
                  setShowDriverInfo={setShowDriverInfo}
                />
              </>
            )}
            
            {/* Seller Selection - Moved to end of the form right before the submit button */}
            <div className="space-y-4">
              <FormField
                control={form.control}
                name="seller"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-lg font-semibold text-[#fa0008]">Consultor*</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione o consultor" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Felipe">Felipe</SelectItem>
                        <SelectItem value="Renan">Renan</SelectItem>
                        <SelectItem value="Renata">Renata</SelectItem>
                        <SelectItem value="Gabriel">Gabriel</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <Button 
              type="submit" 
              className="w-full bg-feijo-red hover:bg-red-700" 
              disabled={isSubmitting || localIsSubmitting}
            >
              {(isSubmitting || localIsSubmitting) ? "Enviando..." : "Enviar Cotação"}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
};

export default AutoInsuranceQuoteForm;

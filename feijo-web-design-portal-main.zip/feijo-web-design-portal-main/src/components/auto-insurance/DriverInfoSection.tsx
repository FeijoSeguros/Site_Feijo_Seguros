
import { FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useFormContext } from "react-hook-form";
import { Dispatch, SetStateAction } from "react";
import type { AutoInsuranceFormData } from "./types";

interface DriverInfoSectionProps {
  showDriverInfo: boolean;
  setShowDriverInfo: Dispatch<SetStateAction<boolean>>;
}

export function DriverInfoSection({ showDriverInfo, setShowDriverInfo }: DriverInfoSectionProps) {
  const form = useFormContext<AutoInsuranceFormData>();
  
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-[#FA0108]">Informações do Principal Condutor</h3>
      
      <FormField
        control={form.control}
        name="is_driver_insured"
        render={({ field }) => (
          <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
            <div className="space-y-0.5">
              <FormLabel className="text-base">Principal Condutor é o Segurado?</FormLabel>
            </div>
            <FormControl>
              <Switch
                checked={field.value}
                onCheckedChange={(value) => {
                  field.onChange(value);
                  setShowDriverInfo(!value);
                }}
              />
            </FormControl>
          </FormItem>
        )}
      />

      {showDriverInfo && (
        <div className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <FormField
              control={form.control}
              name="driver_document_number"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>CPF do Condutor</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="driver_full_name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nome Completo do Condutor</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <FormField
              control={form.control}
              name="driver_birth_date"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Data de Nascimento do Condutor</FormLabel>
                  <FormControl>
                    <Input type="date" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="driver_relationship"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Relação com o Segurado</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <FormField
              control={form.control}
              name="driver_marital_status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Estado Civil do Condutor</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione..." />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="single">Solteiro(a)</SelectItem>
                      <SelectItem value="married">Casado(a)</SelectItem>
                      <SelectItem value="divorced">Divorciado(a)</SelectItem>
                      <SelectItem value="widowed">Viúvo(a)</SelectItem>
                      <SelectItem value="other">Outro</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="driver_gender"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Gênero do Condutor</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione..." />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="male">Masculino</SelectItem>
                      <SelectItem value="female">Feminino</SelectItem>
                      <SelectItem value="other">Outro</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </div>
      )}
    </div>
  );
}

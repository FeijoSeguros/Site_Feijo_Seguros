
import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import { Button } from "@/components/ui/button";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu";
import { Link } from 'react-router-dom';

// Logo URL
const LOGO_URL = "/lovable-uploads/8b7fe028-0dc1-4e27-9566-1cc2f01c47dc.png";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [logoLoaded, setLogoLoaded] = useState(false);

  useEffect(() => {
    // Preload logo image
    const preloadLogo = () => {
      const img = new Image();
      img.onload = () => setLogoLoaded(true);
      img.src = LOGO_URL;
    };
    
    preloadLogo();
  }, []);

  const insuranceTypes = [
    { title: 'Automóvel', path: '/seguros/auto' },
    { title: 'Viagem', path: '/seguros/viagem' },
    { title: 'Residencial', path: '/seguros/residencial' },
    { title: 'Vida', path: '/seguros/vida' },
    { title: 'Condomínio', path: '/seguros/condominio' },
    { title: 'Garantia', path: '/seguros/garantia' },
    { title: 'Empresarial', path: '/seguros/empresarial' },
    { title: 'Plano de Saúde', path: '/seguros/saude' },
  ];

  return (
    <nav className="bg-feijo-darkgray sticky top-0 z-50 shadow-sm">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <Link to="/">
            <img 
              src={LOGO_URL}
              alt="Feijó Seguros" 
              className="h-10 md:h-12"
              loading="eager"
              fetchPriority="high"
            />
          </Link>
        </div>
        
        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-8 text-white">
          <Link to="/" className="hover:text-feijo-red transition-colors font-medium text-sm">
            Início
          </Link>
          <NavigationMenu>
            <NavigationMenuList>
              <NavigationMenuItem>
                <NavigationMenuTrigger className="bg-transparent text-white hover:text-feijo-red hover:bg-transparent focus:bg-transparent text-sm">
                  Seguros                  
                </NavigationMenuTrigger>
                <NavigationMenuContent>
                  <div className="grid w-[200px] gap-1 p-4 bg-white">
                    {insuranceTypes.map((insurance) => (
                      <Link
                        key={insurance.path}
                        to={insurance.path}                      
                        className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-feijo-red hover:text-white text-sm"
                      >
                        {insurance.title}
                      </Link>
                    ))}
                  </div>
                </NavigationMenuContent>
              </NavigationMenuItem>
            </NavigationMenuList>
          </NavigationMenu>
          <a href="#about" className="hover:text-feijo-red transition-colors font-medium text-sm">
            Sobre
          </a>
          <a href="#contact" className="hover:text-feijo-red transition-colors font-medium text-sm">
            Contato
          </a>          
        </div>
        
        {/* Mobile Navigation Button */}
        <div className="md:hidden">
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="text-white hover:text-feijo-red focus:outline-none"
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>
      
      {/* Mobile Navigation Menu */}
      {isOpen && (    
        <div className="md:hidden bg-feijo-lightgray">
          <div className="container mx-auto px-4 py-4 flex flex-col space-y-4">
            <Link to="/" className="text-feijo-darkgray hover:text-feijo-red transition-colors font-medium py-2 text-sm">
              Início
            </Link>
            <div className="space-y-2">
              <p className="text-feijo-red font-medium text-sm">Seguros</p>
              {insuranceTypes.map((insurance) => (
                <Link
                  key={insurance.path}
                  to={insurance.path}
                  className="block pl-4 py-1 text-feijo-darkgray hover:text-feijo-red transition-colors text-sm"
                >
                  {insurance.title}
                </Link>                
              ))}
            </div>
            <a href="#about" className="text-feijo-darkgray hover:text-feijo-red transition-colors font-medium py-2 text-sm">
              Sobre
            </a>
            <a href="#contact" className="text-feijo-darkgray hover:text-feijo-red transition-colors font-medium py-2 text-sm">
              Contato
            </a>            
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;

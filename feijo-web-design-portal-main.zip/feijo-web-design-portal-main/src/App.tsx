
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Register from "./pages/Register";
import NotFound from "./pages/NotFound";
import AutoInsurance from "./pages/insurance/AutoInsurance";
import TravelInsurance from "./pages/insurance/TravelInsurance";
import HomeInsurance from "./pages/insurance/HomeInsurance";
import LifeInsurance from "./pages/insurance/LifeInsurance";
import CondominiumInsurance from "./pages/insurance/CondominiumInsurance";
import BondInsurance from "./pages/insurance/BondInsurance";
import BusinessInsurance from "./pages/insurance/BusinessInsurance";
import HealthInsurance from "./pages/insurance/HealthInsurance";

// Create a QueryClient outside of the component to prevent re-instantiation on render
const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <BrowserRouter>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/cadastro" element={<Register />} />
          <Route path="/seguros/auto" element={<AutoInsurance />} />
          <Route path="/seguros/viagem" element={<TravelInsurance />} />
          <Route path="/seguros/residencial" element={<HomeInsurance />} />
          <Route path="/seguros/vida" element={<LifeInsurance />} />
          <Route path="/seguros/condominio" element={<CondominiumInsurance />} />
          <Route path="/seguros/garantia" element={<BondInsurance />} />
          <Route path="/seguros/empresarial" element={<BusinessInsurance />} />
          <Route path="/seguros/saude" element={<HealthInsurance />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </TooltipProvider>
    </BrowserRouter>
  </QueryClientProvider>
);

export default App;

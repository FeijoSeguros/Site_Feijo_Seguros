
import React from 'react';
import { Button } from "@/components/ui/button";
import { House } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Link } from 'react-router-dom';

const HomeInsurance = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center gap-4 mb-8">
            <House className="text-feijo-red" size={48} />
            <h1 className="text-3xl font-bold text-feijo-darkgray">Seguro Residencial</h1>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 mb-8">
            <div>
              <h2 className="text-xl font-semibold mb-4 text-feijo-darkgray">Proteja seu lar</h2>
              <p className="text-feijo-gray mb-4">
                O seguro residencial oferece proteção completa para sua casa ou apartamento contra diversos riscos,
                garantindo tranquilidade para você e sua família.
              </p>
              <ul className="list-disc list-inside text-feijo-gray space-y-2 mb-6">
                <li>Cobertura contra incêndio</li>
                <li>Proteção contra roubo e furto</li>
                <li>Danos elétricos</li>
                <li>Assistência 24 horas</li>
                <li>Responsabilidade civil familiar</li>
              </ul>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="text-lg font-semibold mb-4 text-feijo-darkgray">Serviços inclusos</h3>
              <ul className="space-y-3 text-feijo-gray">
                <li className="flex items-center gap-2">✓ Chaveiro</li>
                <li className="flex items-center gap-2">✓ Encanador</li>
                <li className="flex items-center gap-2">✓ Eletricista</li>
                <li className="flex items-center gap-2">✓ Vidraceiro</li>
              </ul>
            </div>
          </div>

          <div className="text-center">
            <Link to="/cadastro">
              <Button className="bg-feijo-red text-white hover:bg-red-600">
                Solicitar cotação
              </Button>
            </Link>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default HomeInsurance;

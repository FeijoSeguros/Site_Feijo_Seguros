
import React from 'react';
import { Button } from "@/components/ui/button";
import { Gavel } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Link } from 'react-router-dom';

const BondInsurance = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center gap-4 mb-8">
            <Gavel className="text-feijo-red" size={48} />
            <h1 className="text-3xl font-bold text-feijo-darkgray">Seguro Garantia</h1>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 mb-8">
            <div>
              <h2 className="text-xl font-semibold mb-4 text-feijo-darkgray">Garantia para Licitações</h2>
              <p className="text-feijo-gray mb-4">
                O seguro garantia é fundamental para empresas que participam de licitações públicas,
                garantindo o cumprimento das obrigações contratuais.
              </p>
              <ul className="list-disc list-inside text-feijo-gray space-y-2 mb-6">
                <li>Garantia de proposta</li>
                <li>Garantia de execução</li>
                <li>Adiantamento de pagamento</li>
                <li>Retenção de pagamentos</li>
                <li>Garantia judicial</li>
              </ul>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="text-lg font-semibold mb-4 text-feijo-darkgray">Modalidades</h3>
              <ul className="space-y-3 text-feijo-gray">
                <li className="flex items-center gap-2">✓ Bid Bond</li>
                <li className="flex items-center gap-2">✓ Performance Bond</li>
                <li className="flex items-center gap-2">✓ Advance Payment Bond</li>
                <li className="flex items-center gap-2">✓ Retention Bond</li>
              </ul>
            </div>
          </div>

          <div className="text-center">
            <Link to="/cadastro">
              <Button className="bg-feijo-red text-white hover:bg-red-600">
                Solicitar cotação
              </Button>
            </Link>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default BondInsurance;

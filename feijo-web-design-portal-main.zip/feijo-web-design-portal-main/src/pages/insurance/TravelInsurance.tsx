
import React from 'react';
import { Button } from "@/components/ui/button";
import { Plane } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Link } from 'react-router-dom';

const TravelInsurance = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center gap-4 mb-8">
            <Plane className="text-feijo-red" size={48} />
            <h1 className="text-3xl font-bold text-feijo-darkgray">Seguro Viagem</h1>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 mb-8">
            <div>
              <h2 className="text-xl font-semibold mb-4 text-feijo-darkgray">Viaje com tranquilidade</h2>
              <p className="text-feijo-gray mb-4">
                O seguro viagem é essencial para garantir sua segurança e conforto durante suas viagens nacionais e internacionais.
                Conte com cobertura médica, assistência 24h e diversos outros benefícios.
              </p>
              <ul className="list-disc list-inside text-feijo-gray space-y-2 mb-6">
                <li>Assistência médica internacional</li>
                <li>Cobertura de bagagem</li>
                <li>Cancelamento de viagem</li>
                <li>Atendimento em português 24h</li>
                <li>Cobertura COVID-19</li>
              </ul>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="text-lg font-semibold mb-4 text-feijo-darkgray">Coberturas principais</h3>
              <ul className="space-y-3 text-feijo-gray">
                <li className="flex items-center gap-2">✓ Despesas médicas e hospitalares</li>
                <li className="flex items-center gap-2">✓ Traslado médico</li>
                <li className="flex items-center gap-2">✓ Extravio de bagagem</li>
                <li className="flex items-center gap-2">✓ Invalidez por acidente</li>
              </ul>
            </div>
          </div>

          <div className="text-center">
            <Link to="/cadastro">
              <Button className="bg-feijo-red text-white hover:bg-red-600">
                Fazer cotação
              </Button>
            </Link>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default TravelInsurance;


import React from 'react';
import { Button } from "@/components/ui/button";
import { Heart } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Link } from 'react-router-dom';

const LifeInsurance = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center gap-4 mb-8">
            <Heart className="text-feijo-red" size={48} />
            <h1 className="text-3xl font-bold text-feijo-darkgray">Seguro de Vida</h1>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 mb-8">
            <div>
              <h2 className="text-xl font-semibold mb-4 text-feijo-darkgray">Garanta o futuro de quem você ama</h2>
              <p className="text-feijo-gray mb-4">
                O seguro de vida é um investimento no futuro da sua família, proporcionando proteção financeira
                e tranquilidade em momentos difíceis.
              </p>
              <ul className="list-disc list-inside text-feijo-gray space-y-2 mb-6">
                <li>Morte natural ou acidental</li>
                <li>Invalidez permanente</li>
                <li>Doenças graves</li>
                <li>Assistência funeral</li>
                <li>Auxílio alimentação</li>
              </ul>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="text-lg font-semibold mb-4 text-feijo-darkgray">Coberturas adicionais</h3>
              <ul className="space-y-3 text-feijo-gray">
                <li className="flex items-center gap-2">✓ Diária de internação hospitalar</li>
                <li className="flex items-center gap-2">✓ Doenças graves</li>
                <li className="flex items-center gap-2">✓ Invalidez funcional</li>
                <li className="flex items-center gap-2">✓ Morte acidental</li>
              </ul>
            </div>
          </div>

          <div className="text-center">
            <Link to="/cadastro">
              <Button className="bg-feijo-red text-white hover:bg-red-600">
                Fazer cotação
              </Button>
            </Link>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default LifeInsurance;

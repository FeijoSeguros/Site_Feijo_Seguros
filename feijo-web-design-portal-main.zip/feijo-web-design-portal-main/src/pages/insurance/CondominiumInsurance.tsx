
import React from 'react';
import { Button } from "@/components/ui/button";
import { Building } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Link } from 'react-router-dom';

const CondominiumInsurance = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center gap-4 mb-8">
            <Building className="text-feijo-red" size={48} />
            <h1 className="text-3xl font-bold text-feijo-darkgray">Seguro Condomínio</h1>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 mb-8">
            <div>
              <h2 className="text-xl font-semibold mb-4 text-feijo-darkgray">Proteção completa para seu condomínio</h2>
              <p className="text-feijo-gray mb-4">
                O seguro condomínio oferece proteção abrangente para áreas comuns e estrutura do prédio,
                garantindo a segurança de moradores e funcionários.
              </p>
              <ul className="list-disc list-inside text-feijo-gray space-y-2 mb-6">
                <li>Proteção da estrutura do prédio</li>
                <li>Responsabilidade civil</li>
                <li>Áreas comuns</li>
                <li>Equipamentos e elevadores</li>
                <li>Danos elétricos</li>
              </ul>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="text-lg font-semibold mb-4 text-feijo-darkgray">Coberturas principais</h3>
              <ul className="space-y-3 text-feijo-gray">
                <li className="flex items-center gap-2">✓ Incêndio, raio e explosão</li>
                <li className="flex items-center gap-2">✓ Vendaval e granizo</li>
                <li className="flex items-center gap-2">✓ Responsabilidade civil</li>
                <li className="flex items-center gap-2">✓ Danos elétricos</li>
              </ul>
            </div>
          </div>

          <div className="text-center">
            <Link to="/cadastro">
              <Button className="bg-feijo-red text-white hover:bg-red-600">
                Solicitar cotação
              </Button>
            </Link>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default CondominiumInsurance;

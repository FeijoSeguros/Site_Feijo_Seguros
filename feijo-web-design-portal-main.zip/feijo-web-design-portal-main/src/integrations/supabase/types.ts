export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      auto_insurance_quotes: {
        Row: {
          address: string | null
          armoring_value: number | null
          birth_date: string | null
          chassis_number: string | null
          condutor_menor: string | null
          covers_young_drivers: boolean | null
          created_at: string | null
          document_number: string
          driver_birth_date: string | null
          driver_document_number: string | null
          driver_full_name: string | null
          driver_gender: Database["public"]["Enums"]["gender"] | null
          driver_marital_status:
            | Database["public"]["Enums"]["marital_status"]
            | null
          driver_relationship: string | null
          driver_residence_type:
            | Database["public"]["Enums"]["residence_type"]
            | null
          email: string
          fuel_type: string | null
          full_name: string
          gas_kit_value: number | null
          gender: Database["public"]["Enums"]["gender"] | null
          has_automatic_gate: boolean | null
          has_home_garage: boolean | null
          has_natural_gas: boolean | null
          has_school_garage: boolean | null
          has_sunroof: boolean | null
          has_work_garage: boolean | null
          id: string
          insurance_type: Database["public"]["Enums"]["insurance_type"] | null
          is_armored: boolean | null
          is_driver_insured: boolean | null
          is_financed: boolean | null
          is_new_vehicle: boolean | null
          license_plate: string | null
          manufacture_year: number | null
          marital_status: Database["public"]["Enums"]["marital_status"] | null
          model: string | null
          model_year: number | null
          parking_zip_code: string | null
          phone: string
          policy_file_path: string | null
          residence_type: Database["public"]["Enums"]["residence_type"] | null
          seller: string
          vehicle_usage: Database["public"]["Enums"]["vehicle_usage"] | null
          vehicles_at_residence: number | null
          zip_code: string | null
        }
        Insert: {
          address?: string | null
          armoring_value?: number | null
          birth_date?: string | null
          chassis_number?: string | null
          condutor_menor?: string | null
          covers_young_drivers?: boolean | null
          created_at?: string | null
          document_number: string
          driver_birth_date?: string | null
          driver_document_number?: string | null
          driver_full_name?: string | null
          driver_gender?: Database["public"]["Enums"]["gender"] | null
          driver_marital_status?:
            | Database["public"]["Enums"]["marital_status"]
            | null
          driver_relationship?: string | null
          driver_residence_type?:
            | Database["public"]["Enums"]["residence_type"]
            | null
          email: string
          fuel_type?: string | null
          full_name: string
          gas_kit_value?: number | null
          gender?: Database["public"]["Enums"]["gender"] | null
          has_automatic_gate?: boolean | null
          has_home_garage?: boolean | null
          has_natural_gas?: boolean | null
          has_school_garage?: boolean | null
          has_sunroof?: boolean | null
          has_work_garage?: boolean | null
          id?: string
          insurance_type?: Database["public"]["Enums"]["insurance_type"] | null
          is_armored?: boolean | null
          is_driver_insured?: boolean | null
          is_financed?: boolean | null
          is_new_vehicle?: boolean | null
          license_plate?: string | null
          manufacture_year?: number | null
          marital_status?: Database["public"]["Enums"]["marital_status"] | null
          model?: string | null
          model_year?: number | null
          parking_zip_code?: string | null
          phone: string
          policy_file_path?: string | null
          residence_type?: Database["public"]["Enums"]["residence_type"] | null
          seller?: string
          vehicle_usage?: Database["public"]["Enums"]["vehicle_usage"] | null
          vehicles_at_residence?: number | null
          zip_code?: string | null
        }
        Update: {
          address?: string | null
          armoring_value?: number | null
          birth_date?: string | null
          chassis_number?: string | null
          condutor_menor?: string | null
          covers_young_drivers?: boolean | null
          created_at?: string | null
          document_number?: string
          driver_birth_date?: string | null
          driver_document_number?: string | null
          driver_full_name?: string | null
          driver_gender?: Database["public"]["Enums"]["gender"] | null
          driver_marital_status?:
            | Database["public"]["Enums"]["marital_status"]
            | null
          driver_relationship?: string | null
          driver_residence_type?:
            | Database["public"]["Enums"]["residence_type"]
            | null
          email?: string
          fuel_type?: string | null
          full_name?: string
          gas_kit_value?: number | null
          gender?: Database["public"]["Enums"]["gender"] | null
          has_automatic_gate?: boolean | null
          has_home_garage?: boolean | null
          has_natural_gas?: boolean | null
          has_school_garage?: boolean | null
          has_sunroof?: boolean | null
          has_work_garage?: boolean | null
          id?: string
          insurance_type?: Database["public"]["Enums"]["insurance_type"] | null
          is_armored?: boolean | null
          is_driver_insured?: boolean | null
          is_financed?: boolean | null
          is_new_vehicle?: boolean | null
          license_plate?: string | null
          manufacture_year?: number | null
          marital_status?: Database["public"]["Enums"]["marital_status"] | null
          model?: string | null
          model_year?: number | null
          parking_zip_code?: string | null
          phone?: string
          policy_file_path?: string | null
          residence_type?: Database["public"]["Enums"]["residence_type"] | null
          seller?: string
          vehicle_usage?: Database["public"]["Enums"]["vehicle_usage"] | null
          vehicles_at_residence?: number | null
          zip_code?: string | null
        }
        Relationships: []
      }
      health_insurance_dependents: {
        Row: {
          age: number | null
          birth_date: string
          cpf: string
          id: string
          name: string
          quote_id: string
        }
        Insert: {
          age?: number | null
          birth_date: string
          cpf: string
          id?: string
          name: string
          quote_id: string
        }
        Update: {
          age?: number | null
          birth_date?: string
          cpf?: string
          id?: string
          name?: string
          quote_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "health_insurance_dependents_quote_id_fkey"
            columns: ["quote_id"]
            isOneToOne: false
            referencedRelation: "health_insurance_quotes"
            referencedColumns: ["id"]
          },
        ]
      }
      health_insurance_quotes: {
        Row: {
          created_at: string
          current_plan_file_path: string | null
          document_number: string
          email: string
          has_copayment: boolean
          id: string
          insured_age: number | null
          insured_birth_date: string
          insured_cpf: string
          insured_name: string
          municipality: string
          notes: string | null
          phone: string
          responsible_name: string
          room_type: string
          seller: string
          status: string | null
        }
        Insert: {
          created_at?: string
          current_plan_file_path?: string | null
          document_number: string
          email: string
          has_copayment?: boolean
          id?: string
          insured_age?: number | null
          insured_birth_date: string
          insured_cpf: string
          insured_name: string
          municipality: string
          notes?: string | null
          phone: string
          responsible_name: string
          room_type: string
          seller?: string
          status?: string | null
        }
        Update: {
          created_at?: string
          current_plan_file_path?: string | null
          document_number?: string
          email?: string
          has_copayment?: boolean
          id?: string
          insured_age?: number | null
          insured_birth_date?: string
          insured_cpf?: string
          insured_name?: string
          municipality?: string
          notes?: string | null
          phone?: string
          responsible_name?: string
          room_type?: string
          seller?: string
          status?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      gender: "male" | "female" | "other"
      insurance_type: "new" | "renewal"
      marital_status: "single" | "married" | "divorced" | "widowed" | "other"
      residence_type: "house" | "apartment" | "condominium"
      vehicle_usage: "personal" | "work" | "passenger_transport"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DefaultSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      gender: ["male", "female", "other"],
      insurance_type: ["new", "renewal"],
      marital_status: ["single", "married", "divorced", "widowed", "other"],
      residence_type: ["house", "apartment", "condominium"],
      vehicle_usage: ["personal", "work", "passenger_transport"],
    },
  },
} as const
